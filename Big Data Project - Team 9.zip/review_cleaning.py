
# coding: utf-8

# In[1]:


import pandas as pd


# In[17]:


df = pd.read_csv('yelp.csv', sep="|", usecols=['cool', 'funny', 'stars', 'text', 'useful'])


# In[19]:


df.columns = ['cool', 'funny', 'stars', 'text', 'useful']


# In[3]:


df['review.text'] = df['review.text'].apply(lambda x: x.replace('\n', ' '))


# In[21]:


df.head(20)


# In[5]:


stopword = pd.read_csv('stopword.txt', header=None)


# In[6]:


def add_string(x):
    return ' ' + x + ' '


# In[7]:


def upper_case(x):
    return x.upper()


# In[8]:


stopword_list = list(map(add_string, stopword[0].tolist()))
stopword_upper = list(map(upper_case, stopword_list))


# In[9]:


stopword_upper.append('I ')


# In[10]:


for s in stopword_list:
    df['text'] = df['text'].apply(lambda x: x.replace(s, ' '))
    
for s in stopword_upper:
    df['text'] = df['text'].apply(lambda x: x.replace(s, ' '))


# In[11]:


df.head()


# In[12]:


df['text'][0]


# In[13]:


df.to_csv('yelp.txt', header=None, index=None, sep='|')


# In[45]:


star1 = pd.read_csv('1star.csv', header=None)


# In[46]:


star1.head()


# In[47]:


star1[0] = star1[0].apply(lambda x: x.replace('{"ngram":["', ''))
star1[0] = star1[0].apply(lambda x: x.replace('"', ''))
star1[2] = star1[2].apply(lambda x: x.replace(']', ''))
star1[3] = star1[3].apply(lambda x: x.replace('estfrequency:', ''))
star1[3] = star1[3].apply(lambda x: x.replace('}', ''))


# In[50]:


star1.head()


# In[49]:


star1['review'] = star1[0] + ' ' + star1[1] + ' ' + star1[2]
star1['frequency'] = star1[3]
star1 = star1.drop(columns=[0,1,2,3], axis=1)
star1['star'] = 1


# In[64]:


star2 = pd.read_csv('2star.csv', header=None)

star2[0] = star2[0].apply(lambda x: x.replace('{"ngram":["', ''))
star2[0] = star2[0].apply(lambda x: x.replace('"', ''))
star2[2] = star2[2].apply(lambda x: x.replace(']', ''))
star2[3] = star2[3].apply(lambda x: x.replace('estfrequency:', ''))
star2[3] = star2[3].apply(lambda x: x.replace('}', ''))

star2['review'] = star2[0] + ' ' + star2[1] + ' ' + star2[2]
star2['frequency'] = star2[3]
star2 = star2.drop(columns=[0,1,2,3], axis=1)
star2['star'] = 2


# In[65]:


star3 = pd.read_csv('3star.csv', header=None)

star3[0] = star3[0].apply(lambda x: x.replace('{"ngram":["', ''))
star3[0] = star3[0].apply(lambda x: x.replace('"', ''))
star3[2] = star3[2].apply(lambda x: x.replace(']', ''))
star3[3] = star3[3].apply(lambda x: x.replace('estfrequency:', ''))
star3[3] = star3[3].apply(lambda x: x.replace('}', ''))

star3['review'] = star3[0] + ' ' + star3[1] + ' ' + star3[2]
star3['frequency'] = star3[3]
star3 = star3.drop(columns=[0,1,2,3], axis=1)
star3['star'] = 3


# In[66]:


star4 = pd.read_csv('4star.csv', header=None)

star4[0] = star4[0].apply(lambda x: x.replace('{"ngram":["', ''))
star4[0] = star4[0].apply(lambda x: x.replace('"', ''))
star4[2] = star4[2].apply(lambda x: x.replace(']', ''))
star4[3] = star4[3].apply(lambda x: x.replace('estfrequency:', ''))
star4[3] = star4[3].apply(lambda x: x.replace('}', ''))

star4['review'] = star4[0] + ' ' + star4[1] + ' ' + star4[2]
star4['frequency'] = star4[3]
star4 = star4.drop(columns=[0,1,2,3], axis=1)
star4['star'] = 4


# In[67]:


star5 = pd.read_csv('5star.csv', header=None)

star5[0] = star5[0].apply(lambda x: x.replace('{"ngram":["', ''))
star5[0] = star5[0].apply(lambda x: x.replace('"', ''))
star5[2] = star5[2].apply(lambda x: x.replace(']', ''))
star5[3] = star5[3].apply(lambda x: x.replace('estfrequency:', ''))
star5[3] = star5[3].apply(lambda x: x.replace('}', ''))

star5['review'] = star5[0] + ' ' + star5[1] + ' ' + star5[2]
star5['frequency'] = star5[3]
star5 = star5.drop(columns=[0,1,2,3], axis=1)
star5['star'] = 5


# In[68]:


stars = star1.append(star2).append(star3).append(star4).append(star5)


# In[78]:


stars.shape


# In[79]:


stars.to_csv('stars.csv', index=None)


# In[86]:


cool1 = pd.read_csv('0cool.csv', header=None)

cool1[0] = cool1[0].apply(lambda x: x.replace('{"ngram":["', ''))
cool1[0] = cool1[0].apply(lambda x: x.replace('"', ''))
cool1[2] = cool1[2].apply(lambda x: x.replace(']', ''))
cool1[3] = cool1[3].apply(lambda x: x.replace('estfrequency:', ''))
cool1[3] = cool1[3].apply(lambda x: x.replace('}', ''))

cool1['review'] = cool1[0] + ' ' + cool1[1] + ' ' + cool1[2]
cool1['frequency'] = cool1[3]
cool1 = cool1.drop(columns=[0,1,2,3], axis=1)
cool1['star'] = 5


# In[88]:


cool2 = pd.read_csv('1cool.csv', header=None)

cool2[0] = cool2[0].apply(lambda x: x.replace('{"ngram":["', ''))
cool2[0] = cool2[0].apply(lambda x: x.replace('"', ''))
cool2[2] = cool2[2].apply(lambda x: x.replace(']', ''))
cool2[3] = cool2[3].apply(lambda x: x.replace('estfrequency:', ''))
cool2[3] = cool2[3].apply(lambda x: x.replace('}', ''))

cool2['review'] = cool2[0] + ' ' + cool2[1] + ' ' + cool2[2]
cool2['frequency'] = cool2[3]
cool2 = cool2.drop(columns=[0,1,2,3], axis=1)
cool2['star'] = 5


# In[92]:


cool3 = pd.read_csv('2cool.csv', header=None)

cool3[0] = cool3[0].apply(lambda x: x.replace('{"ngram":["', ''))
cool3[0] = cool3[0].apply(lambda x: x.replace('"', ''))
cool3[2] = cool3[2].apply(lambda x: x.replace(']', ''))
cool3[3] = cool3[3].apply(lambda x: x.replace('estfrequency:', ''))
cool3[3] = cool3[3].apply(lambda x: x.replace('}', ''))

cool3['review'] = cool3[0] + ' ' + cool3[1] + ' ' + cool3[2]
cool3['frequency'] = cool3[3]
cool3 = cool3.drop(columns=[0,1,2,3], axis=1)
cool3['star'] = 5


# In[94]:


cool4 = pd.read_csv('3cool.csv', header=None)

cool4[0] = cool4[0].apply(lambda x: x.replace('{"ngram":["', ''))
cool4[0] = cool4[0].apply(lambda x: x.replace('"', ''))
cool4[2] = cool4[2].apply(lambda x: x.replace(']', ''))
cool4[3] = cool4[3].apply(lambda x: x.replace('estfrequency:', ''))
cool4[3] = cool4[3].apply(lambda x: x.replace('}', ''))

cool4['review'] = cool4[0] + ' ' + cool4[1] + ' ' + cool4[2]
cool4['frequency'] = cool4[3]
cool4 = cool4.drop(columns=[0,1,2,3], axis=1)
cool4['star'] = 5


# In[98]:


cools = cool1.append(cool2).append(cool3).append(cool4)
cools.to_csv('cools.csv', index=None)

