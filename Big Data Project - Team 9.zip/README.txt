File - Purpose
1> Presentation -Team 9 
2> Big Data Final Report - Team 9
3> Queries in Studio3T can be found in the Appendix of the report
4> review_cleaning.py - Python file to clean the reviews before performing sentiment analysis
5> stopword.txt - List of stopwords to be removed before sentiment analysis  
6> Queries for sentiment Analysis in Hive

   hive -e 'SELECT EXPLODE(NGRAMS(SENTENCES(LOWER(text)), 3, 1000)) AS review FROM review WHERE stars=1' > /home/hadoop/1star.csv

   hive -e 'SELECT EXPLODE(NGRAMS(SENTENCES(LOWER(text)), 3, 1000)) AS review FROM review WHERE stars=3' > /home/hadoop/3star.csv

